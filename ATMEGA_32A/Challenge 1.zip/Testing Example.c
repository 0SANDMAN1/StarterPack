#include <stdio.h>

int XOR(int array[], int num_elements) {

    int result = 0;

    for (int i = 0; i < num_elements; i++) { //iterates through each element of the array

        int current_value = 0;

        for (int j = i; j < num_elements; j++) {  //iterates through the elements of the subarray starting from the element selected by the outer loop

            current_value ^= array[j];

            result ^= current_value;
        }
    }
    
    return result;
}

int main() {
    int array[] = {98, 74, 12};

    int num_elements = sizeof(array) / sizeof(array[0]);

    int xor_result = XOR(array, num_elements);

    printf("XOR result: %d\n", xor_result);

    return 0;
}
